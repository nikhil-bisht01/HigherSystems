import "./Home.css";
import React, { useEffect, useState } from "react";

import { Link } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";
function Home() {
  useEffect(() => {
    AOS.init({ duration: 2000 });
  }, []);

  const [isClosed, setIsClosed] = useState(true);
  return (
    <div style={{ backgroundColor: "#D8E9F2" }}>
      <div className="App" style={{ backgroundColor: "#D8E9F2" }}>
        <div className="image-container">
          <img
            src={require("./landing1.png")}
            alt="img"
            className="background-image"
            style={{ position: "sticky" }}
          />
        </div>
        <div
          className="hom-overlay-text"
          style={{
            position: "absolute",
            fontSize: "7rem",
            top: "20%",
            left: "48%",
            fontFamily: "jaldi",
          }}
        >
          <span className="home-imgtext" style={{ marginLeft: "" }}>
            {" "}
            HIGH<span style={{ fontWeight: "normal" }}>ER</span>
          </span>{" "}
          INDIA
          <div style={{ position: "absolute", left: "20%", bottom: "25%" }}>
            <span
              style={{ fontSize: "3rem", color: "red", fontWeight: "normal" }}
            >
              D
            </span>
            <span
              style={{
                fontSize: "3rem",
                color: "#ffffff",
                fontWeight: "normal",
              }}
            >
              elivering
            </span>
            <span
              style={{ fontSize: "3rem", color: "red", fontWeight: "normal" }}
            >
              {" "}
              S
            </span>
            <span
              style={{
                fontSize: "3rem",
                color: "#ffffff",
                fontWeight: "normal",
              }}
            >
              olutions
            </span>
          </div>
          <br style={{ marginBottom: "20px", backgroundColor: "#D8E9F2" }} />
          <button
            style={{
              width: "180px",
              height: "40px",
              color: "#FFFFFF",
              backgroundColor: "#7BC000",
              border: "none",
              borderRadius: "7px",
              fontWeight: "bold",
              marginTop: "120px",
              transition: "background-color 0.3s ease", // Add a smooth transition for the color change
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = "rgba(0, 123, 192, 0)";
              e.target.style.border = "2px solid #007BC0";
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = "#007BC0";
              e.target.style.border = "none";
            }}
          >
            GET IN TOUCH
          </button>
        </div>
        <br />
        <br />

        <div style={{ fontFamily: "Jaldi" }}>
          <h1 style={{ fontSize: "3rem", fontWeight: "bold" }}>
            WELCOME TO HIGHER SYSTEMS
          </h1>

          <div style={{ backgroundColor: "#D8E9F2" }}>
            <p
              classname="para1"
              style={{
                fontSize: "1.5rem",
                backgroundColor: "#D8E9F2",
                fontFamily: "Jaldi",
              }}
            >
              HIGHER SYSTEMS is provider of comprensive end-to-end IT solutions
              to corporate and public sector
              <br /> customers from small to large size enterprises. We offer
              broad spectrum of IT Solutons such as infra solutions.
              <br /> backup storage network, security solutions, wifi
              surveillance and manage services
            </p>
            <br />
            <br />
            <div>
              <h1
                style={{
                  position: "absolute",
                  left: "100px",
                  fontSize: "3.5rem",
                  fontFamily: "jaldi",
                }}
              >
                About us:{" "}
              </h1>
              <br />
              <br />
              <br />
              <br />
              <br />
              <br />
              <p
                style={{
                  position: "absolute",
                  left: "100px",
                  fontSize: "1.5rem",
                  width: "800px",
                  textAlign: "left",
                  fontFamily: "jaldi",
                }}
              >
                Higher Systems is a leading player in the
                <br /> dynamic and competitive software services
                <br /> industry. The company specializes in custom <br />
                software development, IT consulting, cloud
                <br /> services, etc. With a team of highly skilled
                <br /> professionals and a customer-centric
                <br /> approach, Higher Systems has successfully
                <br /> delivered various projects across various
                <br /> industries.
                <br />{" "}
                <p
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "bold",
                    color: "black",
                    textDecorationColor: "#000000",
                  }}
                >
                  {/* <Link to="/about">Read more</Link>  */}
                </p>
              </p>
              <div
                style={{
                  position: "relative",
                  left: "900px",
                  height: "100px",
                  width: "600px",
                  bottom: "100px",
                }}
              >
                {" "}
                <img
                  src={require("./family.png")}
                  alt="img"
                  className="background-image"
                  data-aos="zoom-in"
                />
                <div
                  style={{
                    width: "100%",
                    height: "150px",
                    backgroundColor: "#D8E9F2",
                  }}
                ></div>
              </div>

              <br />
              <div>
                <h1
                  style={{
                    position: "absolute",
                    left: "40%",
                    top: "1700px",
                    fontSize: "3.5rem",
                    fontFamily: "jaldi",
                    color: "#007BC0",
                  }}
                >
                  OUR SERVICES
                </h1>
                <p>
                  {" "}
                  <img
                    src={require("./machine.png")}
                    alt="img"
                    className="machine"
                    data-aos="fade-right"
                  />{" "}
                  <img
                    src={require("./itroom.png")}
                    alt="img"
                    className="itroom"
                    data-aos="fade-up"
                  />
                  <p>
                    {" "}
                    <img
                      src={require("./inovation.png")}
                      alt="img"
                      className="inovation"
                      data-aos="fade-left"
                    />
                  </p>
                </p>
              </div>
              <div>
                <h1 style={{ fontSize: "2.8rem" }}> OUR PROMISES TO YOU</h1>
                <br />
                <div className="imageAndTextContainer">
                  <img
                    style={{
                      marginTop: "73px",
                      width: "650px",
                      height: "600px",
                    }}
                    src={require("./teamwork.png")}
                    alt="img"
                    className="background-image2"
                    data-aos="fade-right"
                  />
                </div>
                <div className="textContainer">
                  <p
                    style={{
                      position: "absolute",
                      fontSize: "1.7rem",
                      textAlign: "left",
                      marginLeft: "48%",
                      bottom: "100px",
                      top: "337%",
                      fontFamily: "jaldi",
                    }}
                  >
                    Higher Systems leverages the experience and domain expertise
                    of IT
                    <br /> infrastructure, implement and optimize a map to help
                    you achieve
                    <br /> maximum value from your investments in enterprise
                    infrastructure
                    <br /> management. Our team evaluates your business needs
                    against
                    <br /> recognized IT process maturity models and delivers
                    packaged &
                    <br /> customized services to implement optimized
                    functionality &
                    <br /> performance. With an emphasis on customer support,
                    quality service,
                    <br /> and credence, Higher Systems provides premium
                    services at
                    <br /> competitive prices. Higher leverages best –in –class
                    portfolio of
                    <br /> products to address complex business processes
                    relevant to your
                    <br /> industry. These solutions help you tap market
                    opportunities
                    <br /> promptly, accelerate processes, cut costs effectively
                    and gain a
                    <br /> competitive edge. Browse through Higher’s web portal
                    to discover a
                    <br /> wide array of services that can help your company
                    grow & succeed.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />

          <br />
          <br />

          <div style={{ fontSize: "2rem" }}>
            {" "}
            <h1 style={{ fontSize: "4rem" }}>Future Outlook</h1>Looking ahead,
            Higher Systems Software Services Provider Company is poised for
            continued growth and success. The company is actively exploring
            opportunities in emerging technologies and markets, with a focus on
            staying ahead of industry trends. Strategic partnerships, continuous
            training programs, and a forward-thinking approach position to
            remain a leader in the ever-evolving software services landscape.
          </div>
          <br />
          <br />
          <div></div>
          <div className="business-footer">
          <div className="business-container">
            <div className="business-row">
              <div className=" business-ft-1">
                <h3>HIGHER INDIA PVT. LTD.</h3>
                <p>Welcome to HIGHER INDIA PVT. LTD., your
                  premier destination for custom software 
                  development,IT consulting, cloud services.</p>

                <div className="business-footer-icon">
                  <i class="fa-brands fa-facebook"></i>
                  <i class="fa-brands fa-instagram"></i>
                  <i class="fa-brands fa-linkedin"></i>
                  
                </div>
              </div>
              <div className="business-ft-2">
                <h5>OUR<span>Services</span></h5>
                <ul>
                  <li className="business-service">
                    <a className="business-service1" href="./Infra">IT Infrastructure Solution</a>
                  </li>
                  <li className="business-service">
                    <a className="business-service1" href="./Business">Business Solution Products</a>
                  </li>
                  <li className="business-service">
                    <a className="business-service1" href="./Implementation">Implementations</a>
                  </li>
                </ul>

              </div>
              <div className="business-ft-3">
                <h5>Contact Info</h5>
                <p><i class="fa-solid fa-phone"></i>01354147831<br /></p>
                <p><i class="fa-solid fa-envelope"></i>sales@higher.co.in<br /></p>
                <p><i class="fa-solid fa-location"></i>2/1, 2-Raipur Road, Nearby Dalanwala
                  Thana Survey Chowk, Dehradun-248004</p>
              </div>
            </div>
          </div>
        </div>
        <div className="business-ft-reserved">
          <h>Higher Systems | All Rights Reserved</h>
        </div>
        </div>
          <div
            className="hamburger-menu"
            onClick={() => {
              setIsClosed(false);
            }}
          >
            <p>🟰</p>
          </div>
          <div
            className="menu-open"
            style={{ display: isClosed ? "none" : "inline" }}
          >
            <p
              onClick={() => setIsClosed(true)}
              style={{ position: "absolute", left: "86%" }}
            >
              <span>❌</span>
            </p>
          </div>
          <div
            className="home-navbar"
            style={{
              backgroundColor: "rgba(0, 0, 0, 0.5",
              position: "fixed",
              left: "0px",
              top: "0px",
              width: "100%",
              height: "100px",
            }}
          >
            <img
              src={require("./logo.png")}
              alt="logo"
              style={{ width: "80px", aspectRatio: 1, marginLeft: "60px" }}
            />
            <div>
              <span>
                <div className="nav-list">
                  <ul>
                    <span className="hom-nav-item">HOME</span>
                    <span className="hom-nav-item">
                      <Link
                        to="/about"
                        style={{ textDecoration: "none", color: "#ffffff" }}
                      >
                        ABOUT
                      </Link>
                    </span>
                    <span className="hom-nav-item">SOLUTIONS</span>
                    <span className="hom-nav-item">
                      <Link
                        to="/connect"
                        style={{ textDecoration: "none", color: "#ffffff" }}
                      >
                        CONTACT US
                      </Link>
                      <span
                        className="hom-nav-item"
                        style={{ marginLeft: "130px" }}
                      >
                        <button className="nav-button">
                          {" "}
                          <Link
                            to="/Login"
                            style={{ textDecoration: "none", color: "#ffffff" }}
                          >
                            Login
                          </Link>
                        </button>
                      </span>
                      <span className="hom-nav-item">
                        <button className="nav-button"> <Link
                            to="/Signup"
                            style={{ textDecoration: "none", color: "#ffffff" }}
                          >Sign Up</Link></button>
                      </span>
                    </span>
                  </ul>
                </div>
              </span>
            </div>
          </div>
        </div>

        <div className="footer">Higher Systems | all Rights Reserved</div>
      </div>
    
  );
}

export default Home;
